<?php
class UserModel {
    private $servername = "10.10.20.11"; // IP della VM db
    private $username = "vagrantuser";    // Nome utente del database
    private $password = "Password&1";        // Password dell'utente
    private $dbname = "test_db";          // Nome del database

    public function getUsers() {
        // Crea una connessione al database
        $conn = new mysqli($this->servername, $this->username, $this->password, $this->dbname);
    
        // Verifica la connessione
        if ($conn->connect_error) {
            die("Connessione fallita: " . $conn->connect_error);
        }
    
        // Esegui la query per ottenere gli utenti
        $sql = "SELECT id, nome, cognome, email, data_creazione FROM utenti;";
        $result = $conn->query($sql);
        $users = [];
    
        if ($result->num_rows > 0) {
            // Estrai i dati in un array
            while($row = $result->fetch_assoc()) {
                $users[] = $row;
            }
            // Debug: Stampa il numero di utenti trovati
            echo "Numero di utenti trovati: " . count($users);
        } else {
            echo "Nessun utente trovato.";
        }
    
        // Chiudi la connessione
        $conn->close();
        return $users; // Restituisce i dati degli utenti
    }
    
}
?>
