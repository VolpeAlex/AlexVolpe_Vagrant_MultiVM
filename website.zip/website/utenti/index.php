<?php
// Abilita il display degli errori
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Autoload delle classi
function autoload($class_name) {
    if (file_exists(__DIR__ . '/controller/' . $class_name . '.php')) {
        include __DIR__ . '/controller/' . $class_name . '.php';
    } elseif (file_exists(__DIR__ . '/model/' . $class_name . '.php')) {
        include __DIR__ . '/model/' . $class_name . '.php';
    }
}

spl_autoload_register('autoload');

// Inizializza il controller
$controller = new UserController();
$controller->index(); // Chiama il metodo index del controller
?>
