<?php
// Includi il modello
require_once __DIR__ . '/../model/UserModel.php';

class UserController {
    private $model;

    public function __construct() {
        // Inizializza il modello
        $this->model = new UserModel();
    }

    public function index() {
        // Ottiene gli utenti dal modello
        $users = $this->model->getUsers();
        // Includi la vista
        include __DIR__ . '/../view/user_view.php';
    }
}
?>
